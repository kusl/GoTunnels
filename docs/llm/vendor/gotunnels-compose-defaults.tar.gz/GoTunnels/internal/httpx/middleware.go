// Package httpx holds transport-level helpers and middleware that do not
// depend on the data store: CORS, request identifiers, panic recovery, body
// size limits, a small in-memory rate limiter, OpenTelemetry HTTP
// instrumentation, and the JSON request/response helpers. Keeping these
// store-agnostic makes them trivial to unit test.
//
// JSON on the wire uses encoding/json/v2 (Go 1.27). Requests are decoded
// strictly: exact-case member names, no unknown members, no duplicate names,
// valid UTF-8 only, and exactly one JSON value per body. Responses are encoded
// deterministically (sorted map keys) and nil slices/maps encode as [] / {}.
package httpx

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/json/v2"
	"errors"
	"fmt"
	"log/slog"
	"net/http"
	"slices"
	"strings"
	"sync"
	"time"

	"go.opentelemetry.io/contrib/instrumentation/net/http/otelhttp"
)

// ctxKey is a private context key type.
type ctxKey int

const requestIDKey ctxKey = iota

// Middleware is the standard http middleware shape.
type Middleware func(http.Handler) http.Handler

// Chain applies middleware in order (the first listed is outermost).
func Chain(h http.Handler, mws ...Middleware) http.Handler {
	for _, mw := range slices.Backward(mws) {
		h = mw(h)
	}
	return h
}

// ---------------------------------------------------------------------------
// CORS
// ---------------------------------------------------------------------------

// OriginAllowed decides the Access-Control-Allow-Origin value to echo for a
// request Origin. Because the browser sends credentials (Bearer token flows
// still trigger CORS), the wildcard cannot be combined with credentials, so we
// echo a specific origin. When allowAny is true any non-empty Origin is echoed.
//
// Entries in allowed may be exact origins ("https://a.example") or wildcard
// patterns with a single "*" standing in for exactly one DNS label in the
// leftmost host position ("https://*.trycloudflare.com"). See
// MatchOriginPattern for the precise rules.
func OriginAllowed(allowed []string, allowAny bool, origin string) (echo string, ok bool) {
	if origin == "" {
		return "", false
	}
	if allowAny {
		return origin, true
	}
	for _, a := range allowed {
		if a == origin {
			return origin, true
		}
		if strings.Contains(a, "*") && MatchOriginPattern(a, origin) {
			return origin, true
		}
	}
	return "", false
}

// MatchOriginPattern reports whether origin matches pattern. A pattern is an
// origin whose host begins with "*." — the "*" stands for exactly one
// non-empty DNS label (no dots), which is the shape Cloudflare Quick Tunnel
// hostnames take (<random-words>.trycloudflare.com). Rules:
//
//   - schemes must match exactly (case-insensitive)
//   - the origin must carry no path, port, userinfo, query, or fragment
//   - "https://*.trycloudflare.com" matches "https://a-b-c.trycloudflare.com"
//     but not "https://a.b.trycloudflare.com" (two labels), not
//     "https://trycloudflare.com" (zero labels), and not
//     "http://a.trycloudflare.com" (scheme mismatch)
//
// Patterns without a leading "*." only match exactly (case-insensitively).
func MatchOriginPattern(pattern, origin string) bool {
	pScheme, pHost, ok := splitOrigin(pattern)
	if !ok {
		return false
	}
	oScheme, oHost, ok := splitOrigin(origin)
	if !ok {
		return false
	}
	if pScheme != oScheme {
		return false
	}
	if !strings.HasPrefix(pHost, "*.") {
		return pHost == oHost
	}
	suffix := pHost[1:] // ".trycloudflare.com"
	if !strings.HasSuffix(oHost, suffix) {
		return false
	}
	label := oHost[:len(oHost)-len(suffix)]
	if label == "" || strings.ContainsAny(label, ".:/") {
		return false
	}
	return true
}

// splitOrigin lowercases and splits "scheme://host" (no path, port allowed as
// part of host verbatim). It rejects anything with a path, query, fragment,
// or userinfo — Origin headers never carry those.
func splitOrigin(o string) (scheme, host string, ok bool) {
	o = strings.ToLower(strings.TrimSpace(o))
	i := strings.Index(o, "://")
	if i <= 0 {
		return "", "", false
	}
	scheme, host = o[:i], o[i+3:]
	if host == "" || strings.ContainsAny(host, "/?#@ ") {
		return "", "", false
	}
	return scheme, host, true
}

// CORS returns middleware that applies the origin policy and answers
// preflight OPTIONS requests.
func CORS(allowed []string, allowAny bool) Middleware {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			origin := r.Header.Get("Origin")
			w.Header().Add("Vary", "Origin")
			if echo, ok := OriginAllowed(allowed, allowAny, origin); ok {
				h := w.Header()
				h.Set("Access-Control-Allow-Origin", echo)
				h.Set("Access-Control-Allow-Credentials", "true")
				h.Set("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Requested-With")
				h.Set("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
				h.Set("Access-Control-Max-Age", "600")
			}
			if r.Method == http.MethodOptions {
				w.WriteHeader(http.StatusNoContent)
				return
			}
			next.ServeHTTP(w, r)
		})
	}
}

// ---------------------------------------------------------------------------
// Request ID
// ---------------------------------------------------------------------------

// maxRequestIDLen bounds an inbound X-Request-Id we are willing to adopt.
const maxRequestIDLen = 128

// RequestID attaches a request identifier to the context and response
// headers. A well-formed inbound X-Request-Id is reused so traces correlate
// across hops; anything oversized or containing characters outside
// [A-Za-z0-9._:-] is replaced, so client input cannot inject into logs.
func RequestID() Middleware {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			id := r.Header.Get("X-Request-Id")
			if !validRequestID(id) {
				id = newID()
			}
			w.Header().Set("X-Request-Id", id)
			ctx := context.WithValue(r.Context(), requestIDKey, id)
			next.ServeHTTP(w, r.WithContext(ctx))
		})
	}
}

// RequestIDFromContext returns the request id, or "" if unset.
func RequestIDFromContext(ctx context.Context) string {
	if v, ok := ctx.Value(requestIDKey).(string); ok {
		return v
	}
	return ""
}

func validRequestID(id string) bool {
	if id == "" || len(id) > maxRequestIDLen {
		return false
	}
	for i := 0; i < len(id); i++ {
		c := id[i]
		switch {
		case c >= 'a' && c <= 'z', c >= 'A' && c <= 'Z', c >= '0' && c <= '9':
		case c == '.' || c == '_' || c == ':' || c == '-':
		default:
			return false
		}
	}
	return true
}

func newID() string {
	b := make([]byte, 16)
	if _, err := rand.Read(b); err != nil {
		return "unknown"
	}
	return hex.EncodeToString(b)
}

// ---------------------------------------------------------------------------
// Recovery
// ---------------------------------------------------------------------------

// Recoverer converts panics into a 500 response and logs them.
// http.ErrAbortHandler is re-panicked: it is the standard library's signal to
// abort the response silently and must reach net/http untouched.
func Recoverer(log *slog.Logger) Middleware {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			defer func() {
				if rec := recover(); rec != nil {
					if rec == http.ErrAbortHandler {
						panic(rec)
					}
					log.ErrorContext(r.Context(), "panic recovered",
						slog.Any("panic", rec),
						slog.String("path", r.URL.Path),
						slog.String("request_id", RequestIDFromContext(r.Context())),
					)
					WriteError(w, http.StatusInternalServerError, "internal server error")
				}
			}()
			next.ServeHTTP(w, r)
		})
	}
}

// ---------------------------------------------------------------------------
// Security headers
// ---------------------------------------------------------------------------

// SecurityHeaders marks every API response as non-sniffable, non-cacheable
// JSON with no referrer leakage. Responses carry session tokens and personal
// data, so no intermediary or browser cache may keep them.
func SecurityHeaders() Middleware {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			h := w.Header()
			h.Set("X-Content-Type-Options", "nosniff")
			h.Set("Referrer-Policy", "no-referrer")
			h.Set("Cache-Control", "no-store")
			h.Set("Cross-Origin-Resource-Policy", "cross-origin")
			next.ServeHTTP(w, r)
		})
	}
}

// ---------------------------------------------------------------------------
// OpenTelemetry HTTP instrumentation
// ---------------------------------------------------------------------------

// Instrument wraps a handler with otelhttp so every request produces a span and
// standard HTTP metrics. It is a no-op-friendly wrapper: when telemetry is
// disabled the global providers are no-ops, so this stays cheap.
func Instrument(h http.Handler, operation string) http.Handler {
	return otelhttp.NewHandler(h, operation)
}

// ---------------------------------------------------------------------------
// Rate limiting (token bucket per key)
// ---------------------------------------------------------------------------

// sweepInterval is how often the limiter drops buckets that have refilled to
// capacity. A full bucket is indistinguishable from a missing one, so
// dropping it changes no decision while keeping memory bounded by the number
// of recently active keys.
const sweepInterval = time.Minute

// RateLimiter is a simple per-key token-bucket limiter safe for concurrent use.
type RateLimiter struct {
	mu        sync.Mutex
	buckets   map[string]*bucket
	rate      float64
	capacity  float64
	now       func() time.Time
	lastSweep time.Time
}

type bucket struct {
	tokens float64
	last   time.Time
}

// NewRateLimiter builds a limiter allowing rate tokens/sec with the given burst.
func NewRateLimiter(ratePerSec, burst float64) *RateLimiter {
	if burst < 1 {
		burst = 1
	}
	return &RateLimiter{
		buckets:  map[string]*bucket{},
		rate:     ratePerSec,
		capacity: burst,
		now:      time.Now,
	}
}

// Allow reports whether an event for key is permitted right now.
func (rl *RateLimiter) Allow(key string) bool {
	rl.mu.Lock()
	defer rl.mu.Unlock()
	now := rl.now()
	rl.sweep(now)
	b, ok := rl.buckets[key]
	if !ok {
		rl.buckets[key] = &bucket{tokens: rl.capacity - 1, last: now}
		return true
	}
	b.tokens = rl.refill(b, now)
	b.last = now
	if b.tokens >= 1 {
		b.tokens--
		return true
	}
	return false
}

// Len reports how many keys are currently tracked.
func (rl *RateLimiter) Len() int {
	rl.mu.Lock()
	defer rl.mu.Unlock()
	return len(rl.buckets)
}

func (rl *RateLimiter) refill(b *bucket, now time.Time) float64 {
	t := b.tokens + now.Sub(b.last).Seconds()*rl.rate
	if t > rl.capacity {
		t = rl.capacity
	}
	return t
}

func (rl *RateLimiter) sweep(now time.Time) {
	if now.Sub(rl.lastSweep) < sweepInterval {
		return
	}
	rl.lastSweep = now
	for k, b := range rl.buckets {
		if rl.refill(b, now) >= rl.capacity {
			delete(rl.buckets, k)
		}
	}
}

// LimitByIP returns middleware that rate-limits using a key derived from the
// request (the provided keyFn, typically a hashed client IP). Rejected
// requests receive 429.
func (rl *RateLimiter) LimitByIP(keyFn func(*http.Request) string) Middleware {
	return rl.LimitWith(keyFn, "rate limit exceeded")
}

// LimitWith is LimitByIP with a caller-supplied 429 message, so endpoints with
// deliberately strict limits (e.g. signup) can tell the person what happened
// and roughly when to retry.
func (rl *RateLimiter) LimitWith(keyFn func(*http.Request) string, message string) Middleware {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			if !rl.Allow(keyFn(r)) {
				WriteError(w, http.StatusTooManyRequests, message)
				return
			}
			next.ServeHTTP(w, r)
		})
	}
}

// ---------------------------------------------------------------------------
// Request body limits
// ---------------------------------------------------------------------------

// DefaultMaxBody is the request body ceiling applied to every route by
// MaxBody, and the default for DecodeJSON. Handlers that expect less tighten
// it further for themselves.
const DefaultMaxBody int64 = 1 << 20

// MaxBody caps every request body at n bytes. It is a backstop for handlers
// that hand the raw request to a library (the WebAuthn ceremonies) or read it
// themselves; reading past the cap fails with *http.MaxBytesError.
func MaxBody(n int64) Middleware {
	if n <= 0 {
		n = DefaultMaxBody
	}
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			if r.Body != nil && r.Body != http.NoBody {
				r.Body = http.MaxBytesReader(w, r.Body, n)
			}
			next.ServeHTTP(w, r)
		})
	}
}

// ---------------------------------------------------------------------------
// JSON helpers
// ---------------------------------------------------------------------------

// responseOptions are the encoding/json/v2 options for every response body.
// Deterministic output keeps responses byte-stable for identical data, which
// makes them diffable and cache-friendly.
var responseOptions = json.Deterministic(true)

// requestOptions are the encoding/json/v2 options for every request body.
// v2 already rejects duplicate names, invalid UTF-8, case-mismatched names,
// and trailing data; unknown members are rejected as well so a typo in a
// client payload fails loudly instead of being silently ignored.
var requestOptions = json.RejectUnknownMembers(true)

const internalErrorBody = `{"error":"internal server error"}` + "\n"

// WriteJSON writes v as JSON with the given status code. The body is encoded
// before anything is written, so an encoding failure becomes a clean 500
// rather than a success status followed by truncated JSON.
func WriteJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	if v == nil {
		w.WriteHeader(status)
		return
	}
	body, err := json.Marshal(v, responseOptions)
	if err != nil {
		slog.Error("httpx: encode response", slog.String("error", err.Error()), slog.Int("status", status))
		w.WriteHeader(http.StatusInternalServerError)
		_, _ = w.Write([]byte(internalErrorBody))
		return
	}
	w.WriteHeader(status)
	_, _ = w.Write(append(body, '\n'))
}

// WriteError writes a JSON error body: {"error": "..."}.
func WriteError(w http.ResponseWriter, status int, msg string) {
	WriteJSON(w, status, map[string]string{"error": msg})
}

// ServerError logs err with the request id and writes a generic 500, so
// internal details never reach the client.
func ServerError(w http.ResponseWriter, r *http.Request, log *slog.Logger, msg string, err error) {
	log.ErrorContext(r.Context(), msg,
		slog.String("error", err.Error()),
		slog.String("request_id", RequestIDFromContext(r.Context())),
	)
	WriteError(w, http.StatusInternalServerError, "internal server error")
}

// DecodeJSON reads a size-limited JSON body into dst, writing an error
// response and returning false on failure: 413 when the body exceeds
// maxBytes, otherwise 400 with a message naming the offending member when
// there is one. maxBytes <= 0 means DefaultMaxBody.
func DecodeJSON(w http.ResponseWriter, r *http.Request, dst any, maxBytes int64) bool {
	if maxBytes <= 0 {
		maxBytes = DefaultMaxBody
	}
	r.Body = http.MaxBytesReader(w, r.Body, maxBytes)
	if err := json.UnmarshalRead(r.Body, dst, requestOptions); err != nil {
		status, msg := decodeProblem(err)
		WriteError(w, status, msg)
		return false
	}
	return true
}

// decodeProblem maps a decode failure to a status and a client-safe message.
func decodeProblem(err error) (int, string) {
	if _, ok := errors.AsType[*http.MaxBytesError](err); ok {
		return http.StatusRequestEntityTooLarge, "request body too large"
	}
	if serr, ok := errors.AsType[*json.SemanticError](err); ok && serr.JSONPointer != "" {
		if errors.Is(serr.Err, json.ErrUnknownName) {
			return http.StatusBadRequest, fmt.Sprintf("unknown field %q", serr.JSONPointer.LastToken())
		}
		return http.StatusBadRequest, fmt.Sprintf("invalid value for %q", serr.JSONPointer.LastToken())
	}
	return http.StatusBadRequest, "invalid JSON body"
}
